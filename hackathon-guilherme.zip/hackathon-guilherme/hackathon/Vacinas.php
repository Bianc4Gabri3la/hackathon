<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vacinas</title>
    <link rel="stylesheet" href="vacinas.css">
    <!-- Link para ícones (Font Awesome) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <script>
        function toggleFields(checkbox, index) {
            const dosesField = document.getElementById('doses_' + index);
            const dateField = document.getElementById('date_' + index);
            if (checkbox.checked) {
                dosesField.style.display = 'block';
                dateField.style.display = 'block';
            } else {
                dosesField.style.display = 'none';
                dateField.style.display = 'none';
            }
        }
    </script>
</head>

<body>
    <div class="container">
        <header>
            <div class="header">
                <img style="width: 250px;" src="imagens/mais saúde ++.png" alt="Mais Saúde">
                <h2>Vacinas do paciente:</h2>
            </div>
        </header>
        <form action="processa_vacinas.php" method="POST">
            <?php 
                $vacinas = [
                    "BCG - ID",
                    "Hepatite B",
                    "Pentavalente",
                    "VIP",
                    "Pneumocócica 10 V",
                    "Rotavírus",
                    "Meningocócica C",
                    "Influenza",
                    "Febre Amarela",
                    "Tríplice Viral",
                    "DTP",
                    "VOP",
                    "Varicela",
                    "Hepatite A",
                    "Tetra Viral",
                    "Meningocócica ACWY",
                    "HPV",
                    "Dupla Adulto",
                    "dTpa"
                ];

                foreach ($vacinas as $key => $vacina):
            ?>
                <div class="vacina-item">
                    <input type="checkbox" id="vacina_<?php echo $key; ?>" name="vacinas[]" value="<?php echo $vacina; ?>" onclick="toggleFields(this, <?php echo $key; ?>)">
                    <label for="vacina_<?php echo $key; ?>"><?php echo $vacina; ?></label>
                    <div id="doses_<?php echo $key; ?>" class="doses-date">
                        <label for="doses_select_<?php echo $key; ?>">Quantas doses</label>
                        <select id="doses_select_<?php echo $key; ?>" name="doses[<?php echo $key; ?>]">
                            <?php for ($i = 1; $i <= 10; $i++): ?>
                                <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div id="date_<?php echo $key; ?>" class="doses-date">
                        <label for="date_input_<?php echo $key; ?>">Data da última vacina</label>
                        <input type="date" id="date_input_<?php echo $key; ?>" name="data[<?php echo $key; ?>]">
                    </div>
                </div>
            <?php endforeach; ?>
            <button type="submit">Enviar</button>
        </form>
    </div>
</body>
</html>
