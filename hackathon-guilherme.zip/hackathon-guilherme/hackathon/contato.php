<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contato</title>
    <link rel="stylesheet" href="dashboard.css">
    <!-- Link para ícones (Font Awesome) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <?php require 'header.php'?>


    <div class="content">
        <h1>Contatos:</h1>
        <h2>Guilherme Borges De Oliveira</h2>
        <p>guilhermeborgesd2@hotmail.com
        </p>
        <p> RA:13796</p>
        <h2>Bianca Gabriela da Silva</h2>
        <p>euteimosinha@hotmail.com
        </p>
        <p> RA:14149</p>
        <h2>Isadora Larsen de Souza</h2>
        <p>isalarsen-2011@hotmail.com
        </p>
        <p> RA:7051</p>
        <h2>Pamela Pereira</h2>
        <p>pamelapereira748@gmail.com
        </p>
        <p> RA:14157</p>
    </div>

    <?php require 'footer.php'?>

    <script>
        function toggleDarkMode() {
            document.body.classList.toggle('dark-mode');
            document.querySelector('.header').classList.toggle('dark-mode');
            document.querySelector('.navbar').classList.toggle('dark-mode');
            document.querySelector('.content').classList.toggle('dark-mode');
            document.querySelector('footer').classList.toggle('dark-mode');
        }
    </script>

</body>
</html>