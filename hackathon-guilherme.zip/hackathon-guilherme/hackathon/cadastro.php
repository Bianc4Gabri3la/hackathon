<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Paciente para Vacina</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&display=swap');
    </style>
    <link rel="stylesheet" type="text/css" href="cadastro.css">
    <script>
        function validateForm() {
            const telefone = document.getElementById('telefone').value;
            const cpf = document.getElementById('cpf').value;
            const telefonePattern = /^\d{11}$/;
            const cpfPattern = /^\d{11}$/;
            
            if (!telefonePattern.test(telefone)) {
                alert('O telefone deve ter exatamente 11 dígitos.');
                return false;
            }

            if (!cpfPattern.test(cpf)) {
                alert('O CPF deve ter exatamente 11 dígitos.');
                return false;
            }

            return true;
        }
    </script>
</head>
<body>
    <div class="container"> 
        
         <img src="imagens/mais saúde ++.png" alt="Logo">
        <h1 class="h1">Cadastro de Paciente</h1>
        <?php
        $showSuccessScreen = false;
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $nome = $_POST['nome'];
            $senha = $_POST['senha'];
            $idade = $_POST['idade'];
            $email = $_POST['email'];
            $telefone = $_POST['telefone'];
            $endereco = $_POST['endereco'];
            $data_nascimento = $_POST['data_nascimento'];
            $nome_acompanhante = $_POST['nome_acompanhante'];
            $cpf = $_POST['cpf'];

            // Validação do telefone e CPF no lado do servidor
            if (strlen($telefone) != 11) {
                $telefoneError = 'O telefone deve ter exatamente 11 dígitos.';
            }

            if (strlen($cpf) != 11) {
                $cpfError = 'CPF invalido.';
            }

            if (empty($telefoneError) && empty($cpfError)) {
                // Aqui você pode adicionar a lógica para salvar os dados no banco de dados
                $showSuccessScreen = true;
            }


        }
        ?>
        
        <?php if ($showSuccessScreen): ?>
            <div id="success-screen" class="screen" style="display: flex;">
                <div class="screen-content">
                    <h2>Paciente cadastrado com sucesso!</h2>
                    <button onclick="window.location.href='cadastro.php'">Novo Cadastro</button>
                    <button onclick="window.location.href='dashboard.php'">Continuar</button>
                </div>
            </div>
        <?php endif; ?>
        
        <form method="post" onsubmit="return validateForm()">
            <input type="text" name="nome" placeholder="Nome" required>
            <input type="text" name="senha" placeholder="Senha" required>
            <input type="number" name="idade" placeholder="Idade" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="number" id="telefone" name="telefone" placeholder="Telefone" required>
            <?php if (!empty($telefoneError)): ?>
                <div class="error"><?php echo $telefoneError; ?></div>
            <?php endif; ?>
            <input type="text" name="endereco" placeholder="Endereço" required>
            <label for="data_nascimento">Data de Nascimento</label>
            <input type="date" id="data_nascimento" name="data_nascimento" required>
            <input type="text" name="nome_acompanhante" placeholder="Nome do Acompanhante" required>
            <input type="number" id="cpf" name="cpf" placeholder="CPF" required>
            <?php if (!empty($cpfError)): ?>
                <div class="error"><?php echo $cpfError; ?></div>
            <?php endif; ?>
            <button type="submit">Cadastrar</button>
        </form>
    </div>
</body>
</html>
