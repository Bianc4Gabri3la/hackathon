<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Paciente para Vacina</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&display=swap');
    </style>
    <link rel="stylesheet" type="text/css" href="cadastro.css">
</head>
<body>
    <div class="container"> 
        
         <img src="imagens/mais saúde ++.png" alt="Logo">
        <h1 class="h1">Cadastro de Paciente</h1>
        <?php
        $showSuccessScreen = false;
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $nome = $_POST['nome'];
            $idade = $_POST['idade'];
            $email = $_POST['email'];
            $telefone = $_POST['telefone'];
            $endereco = $_POST['endereco'];
            $data_nascimento = $_POST['data_nascimento'];

            // Aqui você pode adicionar a lógica para salvar os dados no banco de dados

            $showSuccessScreen = true;
        }
        ?>
        
        <?php if ($showSuccessScreen): ?>
            <div id="success-screen" class="screen" style="display: flex;">
                <div class="screen-content">
                    <h2>Paciente cadastrado com sucesso!</h2>
                    <button onclick="window.location.href='cadastro.php'">Novo Cadastro</button>
                    <button onclick="window.location.href='dashboard.php'">Continuar</button>
                </div>
            </div>
        <?php endif; ?>
        
        <form method="post">
            <input type="text" name="nome" placeholder="Nome" required>
            <input type="number" name="idade" placeholder="Idade" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="number" name="telefone" placeholder="Telefone" required>
            <input type="text" name="endereco" placeholder="Endereço" required>
            <input type="date" name="data_nascimento" placeholder="Data de Nascimento" required>
            <button type="submit">Cadastrar</button>
        </form>
    </div>
</body>
</html>
