<?php
require 'config.php';

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $vacinas = $_POST['vacinas'];
    $doses = $_POST['doses'];
    $datas = $_POST['data'];

    foreach ($vacinas as $key => $vacina) {
        $quantidade_doses = $doses[$key];
        $data_vacina = $datas[$key];

        $sql = "INSERT INTO vacinas_paciente (vacina, doses, data_vacina) VALUES ('$vacina', '$quantidade_doses', '$data_vacina')";
        
        if ($conn->query($sql) === TRUE) {
            echo "Vacina $vacina registrada com sucesso.<br>";
        } else {
            echo "Erro ao registrar vacina $vacina: " . $conn->error . "<br>";
        }
    }
}

$conn->close();
?>
