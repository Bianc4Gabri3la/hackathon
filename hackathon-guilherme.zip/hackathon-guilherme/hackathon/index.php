<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- Importa a fonte Caveat do Google Fonts -->
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&display=swap');
    </style>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <div class="login-container">
            <a href="agente.html" class="agent-link">Entrar como agente</a>
            <form id="login-form" method="POST" action="login.php">
                <img src="imagens/mais saúde ++.png" alt="Logo">
                <h2 style="font-family: 'Caveat', cursive;">Paciente</h2>
                <input type="text" name="cpf" id="cpf" placeholder="CPF" required>
                <input type="password" name="senha" id="senha" placeholder="Senha" required>
                <div id="error-message" style="color: red; margin: 10px 0;">
                    <?php
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        include 'config.php';

                        $cpf = $_POST['cpf'];
                        $senha = $_POST['senha'];

                        // Aqui você pode adicionar a lógica para validar as credenciais do usuário
                        $sql = "SELECT * FROM pacientes WHERE cpf = '$cpf' AND senha = '$senha'";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            echo "Login bem-sucedido!";
                            header("Location: dashboard.php");
                            // Redirecionar para a página de dashboard ou outra página
                            // header("Location: dashboard.php");
                        } else {
                            echo "CPF ou senha incorretos.";
                        }

                        $conn->close();
                    }
                    ?>
                </div>
                <button type="submit">Entrar</button>
                <a href="cadastro.php">Cadastre-se</a>
                <a href="#">Esqueceu sua senha?</a>
            </form>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>
