<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="dashboard.css">
    <!-- Link para ícones (Font Awesome) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="header">
        <div class="logo">
            <img src="imagens/mais saúde ++.png" alt="Logo">
        </div>
        <div class="central-image">
            <img src="imagens/Imagen1.png" alt="Imagem Central">
        </div>
        <div class="icons">
            <i class="fas fa-adjust" onclick="toggleDarkMode()"></i>
            <i class="fas fa-bell"></i>
            <i class="fas fa-user-circle" onclick="window.location.href='perfil.php'"></i>
        </div>
    </div>
    <div class="navbar">
        <a href="#historico-vacina">Histórico de Vacina</a>
        <a href="#chamada-domiciliar">Chamada Domiciliar</a>
        <a href="#calendario-vacinal">Calendário Vacinal</a>
    </div>

    <div class="carousel-container">
        <div class="carousel">
            <img src="imagens/acampamentoVacina.jpg" alt="Imagem 1" class="carousel-image">
            <img src="imagens/vacinaParalisia.jpg" alt="Imagem 2" class="carousel-image">
            <img src="imagens/covid-19.jpg" alt="Imagem 3" class="carousel-image">
            <img src="imagens/mitoVacina.png" alt="Imagem 4" class="carousel-image">
        </div>
        <div class="carousel-controls">
            <button class="prev" onclick="changeSlide(-1)">&#10094;</button>
            <button class="next" onclick="changeSlide(1)">&#10095;</button>
        </div>
    </div>

    <div class="content">
        <h2>A Importância da Vacinação: Protegendo Indivíduos e Comunidades</h2>
        <p>A vacinação desempenha um papel fundamental na proteção da saúde individual e coletiva, sendo uma das intervenções médicas mais eficazes já desenvolvidas pela ciência. Ao longo dos anos, vacinas têm contribuído significativamente para a erradicação de doenças devastadoras e para a redução da morbidade e mortalidade em todo o mundo.</p>

        <p>As vacinas funcionam treinando o sistema imunológico a reconhecer e combater agentes infecciosos específicos, como vírus e bactérias. Essa preparação prévia do sistema imunológico permite que o corpo responda rapidamente e eficientemente quando exposto ao patógeno real. Dessa forma, a vacinação não apenas protege o indivíduo vacinado contra doenças potencialmente graves, mas também desempenha um papel crucial na prevenção da propagação dessas doenças em comunidades inteiras.</p>

        <p>Além de proteger quem recebe a vacina, a imunização em massa cria o que é conhecido como "imunidade de rebanho" ou "imunidade coletiva". Isso ocorre quando uma porcentagem suficientemente alta da população é vacinada, reduzindo a circulação do patógeno e protegendo automaticamente aqueles que não podem ser vacinados por motivos médicos, como bebês muito novos ou pessoas com sistemas imunológicos comprometidos.</p>

        <p>Ao longo da história, vacinas têm sido responsáveis pela erradicação global da varíola e pela quase erradicação da poliomielite. Elas também têm ajudado a controlar surtos de doenças como sarampo, rubéola, difteria, coqueluche e muitas outras. Além disso, a pesquisa contínua e o desenvolvimento de novas vacinas estão expandindo as fronteiras da proteção contra doenças infecciosas emergentes e resistentes aos medicamentos.</p>

        <p>Portanto, é essencial reconhecer que a vacinação não é apenas um ato de proteção pessoal, mas um compromisso com a saúde pública global. É um investimento em um futuro mais saudável e seguro para todos. Ao tomar medidas para garantir que vacinas estejam acessíveis e sejam administradas de maneira eficaz e oportuna, estamos não apenas protegendo nossas próprias vidas, mas também contribuindo para um mundo mais resiliente contra ameaças infecciosas.</p>
    </div>

    <footer>
        <h1>&copy; 2024 + Saúde</h1>
        <a href="#contato">Contato</a> | 
        <a href="#sobre-nos">Sobre Nós</a>
    </footer>

    <script src="carousel.js"></script>
    <script>
        function toggleDarkMode() {
            document.body.classList.toggle('dark-mode');
            document.querySelector('.header').classList.toggle('dark-mode');
            document.querySelector('.navbar').classList.toggle('dark-mode');
            document.querySelector('footer').classList.toggle('dark-mode');
        }
    </script>
</body>
</html>
