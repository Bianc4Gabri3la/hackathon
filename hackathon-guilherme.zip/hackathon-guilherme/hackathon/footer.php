<footer>
        <h1>&copy; 2024 + Saúde</h1>
        <a href="contato.php">Contato</a> | 
        <a href="sobreNos.php">Sobre Nós</a>
    </footer>
