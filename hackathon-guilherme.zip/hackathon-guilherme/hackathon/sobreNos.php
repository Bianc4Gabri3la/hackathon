<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre Nós</title>
    <link rel="stylesheet" href="dashboard.css">
    <!-- Link para ícones (Font Awesome) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <?php require 'header.php'; ?>

    <div class="content">
        <h2>Sobre Nós</h2>
        <p>
            Bem-vindo ao nosso site dedicado à promoção da vacinação! Nosso objetivo é instruir e ajudar as pessoas, especialmente as mais necessitadas, a obterem a vacinação necessária para garantir sua saúde e bem-estar. 
        </p>
        <p>
        Acreditamos que a vacinação é uma parte crucial para manter a comunidade saudável e protegida contra doenças preveníveis. 
        Estamos aqui para fornecer informações precisas e atualizadas, orientações sobre como e onde se vacinar, e suporte para aqueles que enfrentam dificuldades em acessar serviços de saúde.
        </p>
        <p>
            Nossa missão é facilitar o acesso à vacinação, educar sobre a importância das vacinas e assegurar que todos tenham a oportunidade de se proteger e proteger seus entes queridos. 
            Junte-se a nós nessa jornada de saúde e bem-estar, e vamos juntos criar uma comunidade mais forte e saudável!
        </p>
    </div>

    <?php require 'footer.php'; ?>

    <script>
        function toggleDarkMode() {
            document.body.classList.toggle('dark-mode');
            document.querySelector('.header').classList.toggle('dark-mode');
            document.querySelector('.navbar').classList.toggle('dark-mode');
            document.querySelector('.content').classList.toggle('dark-mode');
            document.querySelector('footer').classList.toggle('dark-mode');
        }
    </script>
</body>
</html>
