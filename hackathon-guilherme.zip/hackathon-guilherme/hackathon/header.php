<div class="header">
        <div class="logo">
            <img src="imagens/mais saúde ++.png" alt="Logo">
        </div>
        <div class="central-image">
            <img src="imagens/Imagen1.png" alt="Imagem Central">
        </div>
        <div class="icons">
            <i class="fas fa-adjust" onclick="toggleDarkMode()"></i>
            <i class="fas fa-bell"></i>
            <i class="fas fa-user-circle" onclick="window.location.href='perfil.php'"></i>
        </div>
    </div>
    <div class="navbar">
        <a href="#historico-vacina">Histórico de Vacina</a>
        <a href="#chamada-domiciliar">Chamada Domiciliar</a>
        <a href="#calendario-vacinal">Calendário Vacinal</a>
    </div>